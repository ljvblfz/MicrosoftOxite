
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.

using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.ServiceModel.Samples.XmlRpc
{
    public enum XmlRpcHttpSecurityMode
    {
        None,
        Transport,
        TransportCredentialOnly
    }
}
