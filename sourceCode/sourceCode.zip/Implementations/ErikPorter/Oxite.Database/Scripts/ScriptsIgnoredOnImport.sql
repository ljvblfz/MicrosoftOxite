﻿
/*
This script was created by Visual Studio on 2/11/2009 at 11:48 AM.
Run this script on Oxite.Database to make it the same as erikpo3\sqlexpress.Oxite.Database.dbo.
Please back up your target database before running this script.
*/

GO
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET ARITHABORT ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON

GO

/*
This script was created by Visual Studio on 2/12/2009 at 2:41 PM.
Run this script on Oxite.Database to make it the same as erikpo3\sqlexpress.Oxite.Database.dbo.
Please back up your target database before running this script.
*/

GO
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET ARITHABORT ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON

GO

/*
This script was created by Visual Studio on 2/13/2009 at 1:31 PM.
Run this script on Oxite.Database to make it the same as erikpo3\sqlexpress.Oxite.Database.dbo.
Please back up your target database before running this script.
*/

GO
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET ARITHABORT ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON

GO

/*
This script was created by Visual Studio on 3/2/2009 at 9:57 AM.
Run this script on Oxite.Database to make it the same as erikpo3\sqlexpress.Oxite.Database.dbo.
Please back up your target database before running this script.
*/

GO
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING ON
GO
SET ANSI_WARNINGS ON
GO
SET CONCAT_NULL_YIELDS_NULL ON
GO
SET ARITHABORT ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON

GO
