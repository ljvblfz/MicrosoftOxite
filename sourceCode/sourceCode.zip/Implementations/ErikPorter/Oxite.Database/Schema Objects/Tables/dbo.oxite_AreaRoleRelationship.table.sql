﻿CREATE TABLE [dbo].[oxite_AreaRoleRelationship]
(
[AreaID] [uniqueidentifier] NOT NULL,
[RoleID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]


