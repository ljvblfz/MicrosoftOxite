﻿CREATE TABLE [dbo].[oxite_Language]
(
[LanguageID] [uniqueidentifier] NOT NULL,
[LanguageName] [varchar] (8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
[LanguageDisplayName] [nvarchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]


