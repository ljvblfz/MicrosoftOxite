﻿CREATE NONCLUSTERED INDEX [IX_oxite_PostView_PostID] ON [dbo].[oxite_PostView] ([PostID]) ON [PRIMARY]


