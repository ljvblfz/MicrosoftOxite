﻿CREATE UNIQUE NONCLUSTERED INDEX [IX_oxite_PostViewType_PostViewTypeName] ON [dbo].[oxite_PostViewType] ([PostViewTypeName]) ON [PRIMARY]


