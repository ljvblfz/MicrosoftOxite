﻿CREATE NONCLUSTERED INDEX [IX_oxite_Area] ON [dbo].[oxite_Area] ([AreaName]) ON [PRIMARY]


