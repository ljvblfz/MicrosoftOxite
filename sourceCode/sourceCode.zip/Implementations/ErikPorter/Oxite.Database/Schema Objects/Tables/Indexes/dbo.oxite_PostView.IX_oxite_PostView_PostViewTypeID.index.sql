﻿CREATE NONCLUSTERED INDEX [IX_oxite_PostView_PostViewTypeID] ON [dbo].[oxite_PostView] ([PostViewTypeID]) ON [PRIMARY]


