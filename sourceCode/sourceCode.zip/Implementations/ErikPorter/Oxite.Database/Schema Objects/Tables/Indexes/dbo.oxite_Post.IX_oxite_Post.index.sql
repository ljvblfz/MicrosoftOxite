﻿CREATE NONCLUSTERED INDEX [IX_oxite_Post] ON [dbo].[oxite_Post] ([Slug]) ON [PRIMARY]


