﻿ALTER TABLE [dbo].[oxite_TrackbackOutbound] ADD CONSTRAINT [PK_oxite_TrackbackOutbound] PRIMARY KEY CLUSTERED  ([TrackbackOutboundID]) ON [PRIMARY]


