﻿ALTER TABLE [dbo].[oxite_User] ADD CONSTRAINT [IX_oxite_Username] UNIQUE NONCLUSTERED  ([Username]) ON [PRIMARY]


