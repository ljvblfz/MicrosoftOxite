﻿ALTER TABLE [dbo].[oxite_StringResourceVersion] ADD CONSTRAINT [PK_oxite_StringResourceVersion] PRIMARY KEY CLUSTERED  ([StringResourceKey], [Language], [Version]) ON [PRIMARY]


