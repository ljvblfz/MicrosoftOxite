﻿ALTER TABLE [dbo].[oxite_UserFileResourceRelationship] ADD CONSTRAINT [PK_oxite_UserFileResourceRelationship] PRIMARY KEY CLUSTERED  ([UserID], [FileResourceID]) ON [PRIMARY]


