﻿ALTER TABLE [dbo].[oxite_SiteRedirect] ADD CONSTRAINT [PK_oxite_SiteRedirect] PRIMARY KEY CLUSTERED  ([SiteID], [SiteRedirect]) ON [PRIMARY]


