﻿ALTER TABLE [dbo].[oxite_CommentAnonymous] ADD CONSTRAINT [PK_oxite_CommentAnonymous] PRIMARY KEY CLUSTERED  ([CommentID]) ON [PRIMARY]


