﻿ALTER TABLE [dbo].[oxite_FileResource] ADD CONSTRAINT [PK_oxite_FileResource] PRIMARY KEY CLUSTERED  ([FileResourceID]) ON [PRIMARY]


