﻿ALTER TABLE [dbo].[oxite_PostView] ADD CONSTRAINT [PK_oxite_PostView] PRIMARY KEY CLUSTERED  ([PostViewID]) ON [PRIMARY]


