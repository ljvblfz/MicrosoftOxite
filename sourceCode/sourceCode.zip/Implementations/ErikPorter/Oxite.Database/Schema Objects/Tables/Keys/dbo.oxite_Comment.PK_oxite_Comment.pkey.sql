﻿ALTER TABLE [dbo].[oxite_Comment] ADD CONSTRAINT [PK_oxite_Comment] PRIMARY KEY CLUSTERED  ([CommentID]) ON [PRIMARY]


