﻿ALTER TABLE [dbo].[oxite_Language] ADD CONSTRAINT [PK_oxite_Language] PRIMARY KEY CLUSTERED  ([LanguageID]) ON [PRIMARY]


