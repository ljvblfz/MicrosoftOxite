﻿ALTER TABLE [dbo].[oxite_UserRoleRelationship] ADD CONSTRAINT [PK_oxite_UserRoleRelationship] PRIMARY KEY CLUSTERED  ([UserID], [RoleID]) ON [PRIMARY]


