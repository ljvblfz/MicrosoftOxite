﻿ALTER TABLE [dbo].[oxite_PostTagRelationship] ADD CONSTRAINT [PK_oxite_PostTagRelationship] PRIMARY KEY CLUSTERED  ([PostID], [TagID]) ON [PRIMARY]


