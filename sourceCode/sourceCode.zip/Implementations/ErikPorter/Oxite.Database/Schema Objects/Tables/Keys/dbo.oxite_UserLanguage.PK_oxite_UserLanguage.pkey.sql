﻿ALTER TABLE [dbo].[oxite_UserLanguage] ADD CONSTRAINT [PK_oxite_UserLanguage] PRIMARY KEY CLUSTERED  ([UserID], [LanguageID]) ON [PRIMARY]


