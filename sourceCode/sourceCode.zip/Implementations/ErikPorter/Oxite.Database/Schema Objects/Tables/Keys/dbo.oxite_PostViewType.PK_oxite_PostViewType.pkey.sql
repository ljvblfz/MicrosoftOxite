﻿ALTER TABLE [dbo].[oxite_PostViewType] ADD CONSTRAINT [PK_oxite_PostViewType] PRIMARY KEY CLUSTERED  ([PostViewTypeID]) ON [PRIMARY]


