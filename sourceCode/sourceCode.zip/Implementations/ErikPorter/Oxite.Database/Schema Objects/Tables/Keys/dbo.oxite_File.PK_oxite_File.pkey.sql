﻿ALTER TABLE [dbo].[oxite_File]
	ADD CONSTRAINT [PK_oxite_File]
	PRIMARY KEY (ID)