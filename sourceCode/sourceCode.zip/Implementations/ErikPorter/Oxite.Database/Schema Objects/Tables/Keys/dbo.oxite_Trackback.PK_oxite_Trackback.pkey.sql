﻿ALTER TABLE [dbo].[oxite_Trackback] ADD CONSTRAINT [PK_oxite_Trackback] PRIMARY KEY CLUSTERED  ([TrackbackID]) ON [PRIMARY]


