﻿ALTER TABLE [dbo].[oxite_AreaRoleRelationship] ADD CONSTRAINT [PK_oxite_AreaRoleRelationship] PRIMARY KEY CLUSTERED  ([AreaID], [RoleID]) ON [PRIMARY]


