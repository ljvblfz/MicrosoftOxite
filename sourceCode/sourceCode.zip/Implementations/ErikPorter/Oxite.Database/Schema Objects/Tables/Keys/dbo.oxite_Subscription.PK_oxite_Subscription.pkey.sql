﻿ALTER TABLE [dbo].[oxite_Subscription] ADD CONSTRAINT [PK_oxite_Subscription] PRIMARY KEY CLUSTERED  ([SubscriptionID]) ON [PRIMARY]


