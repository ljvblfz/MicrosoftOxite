﻿ALTER TABLE [dbo].[oxite_MessageOutbound] ADD CONSTRAINT [PK_oxite_MessageOutbound] PRIMARY KEY CLUSTERED  ([MessageOutboundID]) ON [PRIMARY]


