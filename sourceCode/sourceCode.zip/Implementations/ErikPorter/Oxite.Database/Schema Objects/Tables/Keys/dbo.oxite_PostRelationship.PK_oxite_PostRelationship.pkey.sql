﻿ALTER TABLE [dbo].[oxite_PostRelationship] ADD CONSTRAINT [PK_oxite_PostRelationship] PRIMARY KEY CLUSTERED  ([SiteID], [ParentPostID], [PostID]) ON [PRIMARY]


