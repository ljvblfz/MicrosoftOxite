﻿ALTER TABLE [dbo].[oxite_PluginSetting] ADD CONSTRAINT [PK_oxite_PluginSetting] PRIMARY KEY CLUSTERED  ([SiteID], [PluginID], [PluginSettingName]) ON [PRIMARY]


