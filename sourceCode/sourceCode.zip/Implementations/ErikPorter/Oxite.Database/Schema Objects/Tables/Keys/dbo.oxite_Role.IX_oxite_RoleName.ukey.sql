﻿ALTER TABLE [dbo].[oxite_Role] ADD CONSTRAINT [IX_oxite_RoleName] UNIQUE NONCLUSTERED  ([RoleName]) ON [PRIMARY]


