﻿ALTER TABLE [dbo].[oxite_SubscriptionAnonymous] ADD CONSTRAINT [PK_oxite_SubscriptionAnonymous] PRIMARY KEY CLUSTERED  ([SubscriptionID]) ON [PRIMARY]


