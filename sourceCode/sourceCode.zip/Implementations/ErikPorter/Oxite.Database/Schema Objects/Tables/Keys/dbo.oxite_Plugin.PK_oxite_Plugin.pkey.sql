﻿ALTER TABLE [dbo].[oxite_Plugin] ADD CONSTRAINT [PK_oxite_Plugin] PRIMARY KEY CLUSTERED  ([SiteID], [PluginID]) ON [PRIMARY]


