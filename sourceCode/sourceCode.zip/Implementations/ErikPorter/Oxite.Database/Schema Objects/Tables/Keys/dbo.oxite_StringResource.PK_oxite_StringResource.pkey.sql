﻿ALTER TABLE [dbo].[oxite_StringResource] ADD CONSTRAINT [PK_oxite_StringResource] PRIMARY KEY CLUSTERED  ([StringResourceKey]) ON [PRIMARY]


