﻿ALTER TABLE [dbo].[oxite_PostAreaRelationship] ADD CONSTRAINT [PK_oxite_PostAreaRelationship] PRIMARY KEY CLUSTERED  ([PostID], [AreaID]) ON [PRIMARY]


