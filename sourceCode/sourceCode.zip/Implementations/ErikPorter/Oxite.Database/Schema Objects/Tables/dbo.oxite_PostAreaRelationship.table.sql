﻿CREATE TABLE [dbo].[oxite_PostAreaRelationship]
(
[PostID] [uniqueidentifier] NOT NULL,
[AreaID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]


