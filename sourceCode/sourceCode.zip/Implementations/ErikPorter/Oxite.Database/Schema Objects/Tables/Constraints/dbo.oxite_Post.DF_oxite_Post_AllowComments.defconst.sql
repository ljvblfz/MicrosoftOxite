﻿ALTER TABLE [dbo].[oxite_Post] ADD CONSTRAINT [DF_oxite_Post_AllowComments] DEFAULT ((0)) FOR [CommentingDisabled]


