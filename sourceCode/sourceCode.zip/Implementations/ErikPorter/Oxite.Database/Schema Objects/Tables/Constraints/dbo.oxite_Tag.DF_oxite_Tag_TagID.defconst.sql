﻿ALTER TABLE [dbo].[oxite_Tag] ADD CONSTRAINT [DF_oxite_Tag_TagID] DEFAULT (newid()) FOR [TagID]


