﻿ALTER TABLE [dbo].[oxite_Site] ADD CONSTRAINT [DF_oxite_Site_CommentingDisabled] DEFAULT ((0)) FOR [CommentingDisabled]


