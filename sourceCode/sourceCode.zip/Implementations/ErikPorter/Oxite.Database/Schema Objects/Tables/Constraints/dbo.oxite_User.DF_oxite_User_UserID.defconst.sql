﻿ALTER TABLE [dbo].[oxite_User] ADD CONSTRAINT [DF_oxite_User_UserID] DEFAULT (newid()) FOR [UserID]


