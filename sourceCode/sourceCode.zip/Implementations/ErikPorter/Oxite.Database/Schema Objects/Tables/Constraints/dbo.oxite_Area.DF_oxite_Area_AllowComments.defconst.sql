﻿ALTER TABLE [dbo].[oxite_Area] ADD CONSTRAINT [DF_oxite_Area_AllowComments] DEFAULT ((0)) FOR [CommentingDisabled]


