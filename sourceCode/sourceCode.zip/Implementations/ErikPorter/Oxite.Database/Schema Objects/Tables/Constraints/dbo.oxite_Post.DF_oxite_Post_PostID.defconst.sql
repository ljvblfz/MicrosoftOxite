﻿ALTER TABLE [dbo].[oxite_Post] ADD CONSTRAINT [DF_oxite_Post_PostID] DEFAULT (newid()) FOR [PostID]


