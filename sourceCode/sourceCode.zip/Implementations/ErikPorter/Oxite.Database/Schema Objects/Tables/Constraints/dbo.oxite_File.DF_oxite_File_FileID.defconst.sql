﻿ALTER TABLE [dbo].[oxite_FileResource] ADD CONSTRAINT [DF_oxite_FileResource_FileResourceID] DEFAULT (newid()) FOR [FileResourceID]


