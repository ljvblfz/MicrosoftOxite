﻿ALTER TABLE [dbo].[oxite_Site] ADD CONSTRAINT [DF_oxite_Site_ServiceRetryCountDefault] DEFAULT ((3)) FOR [ServiceRetryCountDefault]


