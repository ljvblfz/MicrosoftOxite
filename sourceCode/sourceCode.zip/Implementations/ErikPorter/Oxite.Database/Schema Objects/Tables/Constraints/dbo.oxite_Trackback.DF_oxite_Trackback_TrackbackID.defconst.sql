﻿ALTER TABLE [dbo].[oxite_Trackback] ADD CONSTRAINT [DF_oxite_Trackback_TrackbackID] DEFAULT (newid()) FOR [TrackbackID]


