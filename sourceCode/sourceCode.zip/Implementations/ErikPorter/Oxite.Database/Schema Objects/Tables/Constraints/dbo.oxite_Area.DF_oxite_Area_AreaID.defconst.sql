﻿ALTER TABLE [dbo].[oxite_Area] ADD CONSTRAINT [DF_oxite_Area_AreaID] DEFAULT (newid()) FOR [AreaID]


