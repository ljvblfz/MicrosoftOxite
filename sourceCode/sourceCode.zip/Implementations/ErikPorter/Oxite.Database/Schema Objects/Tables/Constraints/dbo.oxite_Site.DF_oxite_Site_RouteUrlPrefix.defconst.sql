﻿ALTER TABLE [dbo].[oxite_Site] ADD CONSTRAINT [DF_oxite_Site_RouteUrlPrefix] DEFAULT (N'') FOR [RouteUrlPrefix]


