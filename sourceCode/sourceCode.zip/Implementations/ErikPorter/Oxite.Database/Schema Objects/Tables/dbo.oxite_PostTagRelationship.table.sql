﻿CREATE TABLE [dbo].[oxite_PostTagRelationship]
(
[PostID] [uniqueidentifier] NOT NULL,
[TagID] [uniqueidentifier] NOT NULL,
[TagDisplayName] nvarchar(max) NULL
) ON [PRIMARY]


