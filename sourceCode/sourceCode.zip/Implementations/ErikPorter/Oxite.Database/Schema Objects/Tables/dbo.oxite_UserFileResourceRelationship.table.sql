﻿CREATE TABLE [dbo].[oxite_UserFileResourceRelationship]
(
[UserID] [uniqueidentifier] NOT NULL,
[FileResourceID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]


