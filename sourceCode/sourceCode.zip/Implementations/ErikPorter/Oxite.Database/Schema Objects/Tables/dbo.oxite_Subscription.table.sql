﻿CREATE TABLE [dbo].[oxite_Subscription]
(
[SubscriptionID] [uniqueidentifier] NOT NULL,
[PostID] [uniqueidentifier] NOT NULL,
[UserID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]


