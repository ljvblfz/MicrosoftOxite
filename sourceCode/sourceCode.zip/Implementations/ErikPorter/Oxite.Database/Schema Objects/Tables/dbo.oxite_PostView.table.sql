﻿CREATE TABLE [dbo].[oxite_PostView]
(
[PostID] [uniqueidentifier] NOT NULL,
[PostViewTypeID] [uniqueidentifier] NOT NULL,
[PostViewID] [uniqueidentifier] NOT NULL,
[PostViewCount] [int] NOT NULL,
[PostViewDate] [datetime] NOT NULL
) ON [PRIMARY]


