﻿CREATE TABLE [dbo].[oxite_UserRoleRelationship]
(
[UserID] [uniqueidentifier] NOT NULL,
[RoleID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]


