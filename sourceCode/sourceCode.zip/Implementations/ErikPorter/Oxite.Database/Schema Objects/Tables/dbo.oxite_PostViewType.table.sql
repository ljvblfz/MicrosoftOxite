﻿CREATE TABLE [dbo].[oxite_PostViewType]
(
[PostViewTypeID] [uniqueidentifier] NOT NULL,
[PostViewTypeName] [nvarchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]


