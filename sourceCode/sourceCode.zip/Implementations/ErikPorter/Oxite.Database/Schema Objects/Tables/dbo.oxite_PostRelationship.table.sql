﻿CREATE TABLE [dbo].[oxite_PostRelationship]
(
[SiteID] [uniqueidentifier] NOT NULL,
[ParentPostID] [uniqueidentifier] NOT NULL,
[PostID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]


