﻿CREATE TABLE [dbo].[oxite_UserLanguage]
(
[UserID] [uniqueidentifier] NOT NULL,
[LanguageID] [uniqueidentifier] NOT NULL
) ON [PRIMARY]


