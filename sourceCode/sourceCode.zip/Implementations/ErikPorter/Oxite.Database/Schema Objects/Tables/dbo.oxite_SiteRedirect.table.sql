﻿CREATE TABLE [dbo].[oxite_SiteRedirect]
(
[SiteID] [uniqueidentifier] NOT NULL,
[SiteRedirect] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
) ON [PRIMARY]


