The Group attribute is applied to a  property of the plug-in class.  It allows the plug-in creator to specify the name of the group that the property should be displayed in withn the configuration UI and the order in which the group should appear.

**Note:**  If there are two groups with the same name but different order values, there will be two groups with the same name in the configuration UI.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [Group("Disclaimer", // Name of the group
        1)] // Order in which the group should appear in the UI
    ...
    public string DisclaimerText
    {
        get;
        set;
    }
...
}
}}

**Display:**
