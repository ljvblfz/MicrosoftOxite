## Frequently Asked Questions

**Q:** Why do we need another blog engine?
**A:** At the time of this post, there currently aren't any big ASP.NET MVC example applications.  Oxite is meant to be a good example to learn about ASP.NET MVC.  At the same time, we think it is a useful sample to get a site of your own going too.

**Q:** I'm not a developer.  Is Oxite for me?
**A:** Currently, no.  Oxite is targeted at developers who want to learn ASP.NET MVC.  That said, if you're a devigner (someone who is both a developer + designer) you might really like Oxite too.  We work well in Visual Studio Express.  This is a community project.  If the community decides to build this to work well for consumers down the road we won't stop it, and then Oxite would be for you.

More coming soon...