The Int32RangeValidation attribute is applied to a int-type property of the plug-in class.  It allows the plug-in creator to specify that the value of the property must fall within a certain range.  If the configured value is not within that range, appropriate error messaging is displayed in the UI.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [Int32RangeValidation(100, 2000)](Int32RangeValidation(100,-2000))
    ...
    public int DisclaimerInteger
    {
        get;
        set;
    }
...
}
}}

**Display:**
