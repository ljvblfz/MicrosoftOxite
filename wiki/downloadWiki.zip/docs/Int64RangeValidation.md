The Int64RangeValidation attribute is applied to a long-type property of the plug-in class.  It allows the plug-in creator to specify that the value of the property must fall within a certain range.  If the configured value is not within that range, appropriate error messaging is displayed in the UI.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [Int64RangeValidation(100, 2000)](Int64RangeValidation(100,-2000))
    ...
    public long DisclaimerLong
    {
        get;
        set;
    }
...
}
}}

**Display:**
