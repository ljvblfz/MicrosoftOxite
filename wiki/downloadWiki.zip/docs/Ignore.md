The Ignore attribute is applied to a  property of the plug-in class.  It allows the plug-in creator to specify that a property should not be displayed for edit in the configuration UI.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [Ignore](Ignore)
    ...
    public string NonConfigurableText
    {
        get;
        set;
    }
...
}
}}

**Display:**
