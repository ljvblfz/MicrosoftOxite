The CommentAdded event is fired when a comment is added to a blog post or another comment.  The event will be fired after the comment information is successfully saved.

![Adding a comment](CommentAdded_commentaddedthumb.jpg|http://oxite.codeplex.com/Wiki/View.aspx?title=CommentAddedImage)

**Example:**

{{
public class MyCustomPlugin
{
    public void CommentAdded(ServiceContext context, CommentReadOnly comment)
    {
    }
}
}}