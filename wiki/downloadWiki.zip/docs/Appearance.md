The Appearance attribute is applied to a property of the plug-in class.  It allows the plug-in creator to specify the height and width style values of the UI element representing the property on the configuration screen.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [Appearance(Width = "30%", Height = "30%")](Appearance(Width-=-_30%_,-Height-=-_30%_))
    ...
    public string DisclaimerText
    {
        get;
        set;
    }
...
}
}}

**Display:**
