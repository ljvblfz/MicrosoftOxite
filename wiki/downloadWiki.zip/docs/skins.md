The following is a list of known, publicly available skins for Oxite.  To learn more about skinning check out [How to Skin Oxite](skinning).

|| Skin || Preview || Better Preview ||
| [Titus](http://tobint.com/titus.zip) by [Tobin Titus](http://tobint.com) | ![](skins_titus_200x200.png) | [Large image](skins_titus_450x450.png) |
| [TheLab](http://nathan.heskew.com/Oxite-Skins/TheLab) by [Nathan Heskew](http://nathan.heskew.com) | ![](skins_thelab_200x139.png) | [Large image](skins_thelab_1000x809.png) |

If you have a skin publicly availabe and you'd like it listed here, please send us a message or add a comment and we'll get it added.