The StringValidation attribute is applied to a string-type property of the plug-in class.  It allows the plug-in creator to specify a min and max length for the property.  If an invalid value is entered in the configuration screen, the appropriate error messaging is displayed.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [StringValidation(MaxLength = 1000,
        MinLength = 5)]
    ...
    public string Disclaimer
    {
        get;
        set;
    }
...
}
}}

**Display:**
