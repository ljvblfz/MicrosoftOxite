The Category attribute is applied to the plug-in class.  It allows the plug-in creator to specify a category that the plug-in belongs to.

**Example:**

{{
[Category("Disclaimer")](Category(_Disclaimer_))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**