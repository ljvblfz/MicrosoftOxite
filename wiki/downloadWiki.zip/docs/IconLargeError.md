The IconLargeError attribute is applied to the plug-in class.  It allows the plug-in creator to specify a large icon to displayed in association with the plug-in in the UI.  This icon will be displayed when the plug-in is in an error state.  This typically will occur when there is a problem loading the plug-in.  This can either be an absolute path or the simple file name of the icon if the icon file is located in the images directory of the plug-in folder structure.

![](IconLargeError_folderstructure.jpg)

**Example:**

{{
[IconLargeError("IconLargeError.png")](IconLargeError(_IconLargeError.png_))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
