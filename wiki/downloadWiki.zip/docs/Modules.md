_**Overview**_

Modules are the basic building blocks of Oxite and can be mixed and matched based on the needs of the site.   Each module provides an increment of functionality, examples being:  Site Search, Authentication, and CMS functionality.  The module will contain anything needed to enable the functionality except for the related views.  This may include Models, Model Binders, Filters, etc.

_**Topics**_

* How To's
	* [How to create a module](How-to-create-a-module)
* OOB Oxite Modules
	* [Forms Authentication](Forms-Authentication)
	* [Core](Core)
	* [Plugins](Plugins)
	* [Blogs](Blogs)
	* [CMS](CMS)
	* [Membership](Membership)
	* [Asp.Net Cache](Asp.Net-Cache)
	* [BlogML](BlogML)
	* [MetaWeblog](MetaWeblog)
	* [Setup](Setup)
	* [Search](Search)
	* [Conferences](Conferences)
	* [Bing](Bing)