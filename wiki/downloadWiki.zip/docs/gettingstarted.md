# Getting Started with Oxite -- Development Machine

## Prerequisites
You can use the following versions of Windows to develop and run Oxite: Windows XP, Windows Server 2003, Windows Vista, Windows Server 2008, Windows 7.

## System Requirements
We'll outline our minimum suggestions for developer tools. Feel free to use more exhaustive tools (like Visual Studio 2008 or SQL Server 2008) where you'd like. In some cases, older versions (Visual Web Developer 2005 Express Edition and SQL Server 2005 Express Edition) are also valid options.

**Note**: You might find it helpful to right-click any of the following Hyperlinks and select Open in New Windows or Open in New Tab so you can easily get back to these instructions.

## 1) Install Visual Web Developer 2008 Express Edition and SQL Server 2008 Express Edition

Visit the [Microsoft Visual Studio Express Editions Download Page](http://www.microsoft.com/express/download/). Select the language and click on the 'Download' link in the purple box on the page labeled Microsoft Visual Web Developer 2008 Express Edition.

**Note**: Follow all instructions to successfully complete this and any subsequent installations including (important) the SQL Server 2008 Express Edition option and follow any prompts for operating system restarts.

## 2) Install ASP.NET MVC 1.0
Oxite requires ASP.NET MVC 1.0, which you can install from [the download page](http://www.microsoft.com/downloads/details.aspx?FamilyID=53289097-73ce-43bf-b6a6-35e00103cb4b&displaylang=en). Scroll down the page until you see the **Files in This Download** section. There are three files available for download: release notes, source and installer. Click on the Download button next to the 1.8 MB file named **AspNetMVC1.msi**. Click on the ensuing file download and run warnings (these will be different depending on your browser) and agree to the license agreement in the installation wizard to complete the install. For those on Windows Vista or Windows 7 there will be at least one User Account Control prompt during this process.

**Important Note**: It is important that we are doing this step **after** the installation of Microsoft Visual Web Developer Express as ASP.NET MVC does some configuration of templates and features that the VWD Express product needs to be able to run MVC projects.

## 3) Download an Oxite Release or Source
Now it is time to grab a recent release or the most current drop of the source.

### Release or Source Code checkin: Which one to get?
In general you should get the most recent release, as that is a drop of the code that we explicitly chose to package up for people to download. Individual source code checkins are more up-to-date and may contain bug fixes since a release was created, but they may also contain new bugs that just haven't been found yet. Downloading from the source code tab also brings down more files that you need, because it brings down a full copy of everything we have checked into this codeplex project. Having said that, you can look down the list of checkins to see if there is any important functionality or changes that have been done since the last release, and then make your own decision about what to download.

Regardless of what type of source you choose, you end up pulling down a .zip file full of code, images, binaries, etc... unzip that file into a folder where you have read/write access. To avoid any security access issues, I would stick with a folder that is under your user directory (a folder on the desktop or in your 'Documents' folder for example).

Open up the new directory full of files when you've extracted them. If you've downloaded a release, then the top level folders within this new folder will be the various projects that make up the Oxite sample, including /OxiteSite, /bin and others. This is the root of the Oxite solution. If you've downloaded a full source code check-in, then the top-level folder will contain /Setup and /Oxite, and the root of the solution will be under the /Oxite folder. Remember the path to that root folder, you'll need it in a minute.

## 4) Install Dependencies
Oxite depends on a few external libraries that you'll need to install in order to get up and running. 

### 4A) Install Unity Application Block 1.2
Oxite uses Unity Application Block as our dependency injection container. Download and run the setup program (MSI) from Microsoft downloads at [http://www.microsoft.com/downloads/details.aspx?FamilyId=2C8B79E7-AE56-4F90-822E-A1E43C49D12E&displaylang=en](http://www.microsoft.com/downloads/details.aspx?FamilyId=2C8B79E7-AE56-4F90-822E-A1E43C49D12E&displaylang=en).

### 4B) Install xunit 1.1
Oxite uses xunit as it's test framework. Download the xunit-1.1.zip file (the first one in the list) from Codeplex at [http://www.codeplex.com/xunit/Release/ProjectReleases.aspx?ReleaseId=16811](http://www.codeplex.com/xunit/Release/ProjectReleases.aspx?ReleaseId=16811) and unzip the contents to your **\Oxite\bin\** folder.

### 4C) Install BlogML 2.0
Oxite uses the BlogML library to provide a simple way for you to import your old blog entries into the system. Download the library from Codeplex at  [http://www.codeplex.com/BlogML/Release/ProjectReleases.aspx?ReleaseId=171](http://www.codeplex.com/BlogML/Release/ProjectReleases.aspx?ReleaseId=171) and unzip the **\BlogML 2.0\DotNet API\binary\BlogML.dll** file to your **\Oxite\bin\** folder.

## 5) Open and Run
In Visual Web Developer select **File > Open Project** from the menu. In the **Open Project dialog box** select the **\Oxite\Oxite.sln** file and click the **Open** button.

You may be prompted this is not a trusted location. You can click OK to ignore if it is running in a place where you have read/write permission.

You may be prompted with a 'source code provider for this solution can not be found' message. Select 'Yes' to permanently remove the source code control bindings from the project.

Select **View > Solution Explorer** from the menu.
Select the **Solution 'Oxite'** top level node In the Solution Explorer.
Select **Project > Properties** from the menu.
In the **Solution 'Oxite' Property Pages** dialog box...
- Select the **Startup Project** item in the left list.
- Select the **Single startup project** option on the right.
- Select **Oxite Site** from the drop down list.
- Click the OK button.
Select Debug > Start Debugging from the menu.

If everything works as expected, you should have a browser window open in a few moments with the sample data's first post 'World.Hello()' up and visible. 

Here's an article going over how to [Publish to Oxite from Windows Live Writer](http://capitalcoder.com/Blog/Using-Windows-Live-Writer-with-Oxite)