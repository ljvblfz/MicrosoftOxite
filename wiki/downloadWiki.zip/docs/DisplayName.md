The DisplayName attribute is applied to the plug-in class.  It allows the plug-in creator to specify a name for the plug-in that will be displayed in the Oxite UI.

**Example:**

{{
[DisplayName("Disclaimer Selector")](DisplayName(_Disclaimer-Selector_))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
