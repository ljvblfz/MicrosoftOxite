Oxite exposes events to a plug-in via method signature/naming convention.  So in order to hook to an event, a plug-in writer simply needs to add a method to their plug-in class that has the correct name, takes the right parameter types, and returns the correct type.

**Example:**

{{
public class MyCustomPlugin
{
    public PluginPostInput ProcessInputOfPostOnAdd(PluginPostInput post)
    {
    }
}
}}
This defines a custom plug-in that hooks to the [ProcessInputOfPostOnAdd](ProcessInputOfPostOnAdd) event.  This will allow the plug-in to manipulate elements of a blog post before it is saved to the database.
