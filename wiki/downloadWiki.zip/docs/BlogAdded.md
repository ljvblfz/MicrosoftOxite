The BlogAdded event is fired when a new Blog is added to the site.  The event will be fired after the Blog information is successfully saved.

**Example:**

{{
public class MyCustomPlugin
{
    public void BlogAdded(ServiceContext context, BlogReadOnly blog)
    {
    }
}
}}