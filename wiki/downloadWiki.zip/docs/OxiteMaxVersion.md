The OxiteMaxVersion attribute is applied to the plug-in class.  It allows the plug-in creator to specify the maximum version number of Oxite that the plug-in is compatible with.

**Example:**

{{
[OxiteMaxVersion(1, 0, 0, 0)](OxiteMaxVersion(1,-0,-0,-0))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
