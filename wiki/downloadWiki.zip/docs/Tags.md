The Tags attribute is applied to the plug-in class.  It allows the plug-in creator to specify a list of tags that the plug-in should be associated with.

**Example:**

{{
[Tags("Blog", "Disclaimer")](Tags(_Blog_,-_Disclaimer_))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
