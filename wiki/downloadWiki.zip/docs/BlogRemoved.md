The BlogRemoved event is fired when an Blog of the site is removed.  The event will be fired after the Blog information is successfully saved.

**Example:**

{{
public class MyCustomPlugin
{
    public void BlogRemoved(ServiceContext context, BlogReadOnly blog)
    {
    }
}
}}