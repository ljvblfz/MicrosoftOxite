The DefaultValue attribute is applied to a  property of the plug-in class.  It allows the plug-in creator to specify a default value for the property.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [DefaultValue("All opinions are strictly those of the author.")](DefaultValue(_All-opinions-are-strictly-those-of-the-author._))
    ...
    public string DisclaimerText
    {
        get;
        set;
    }
...
}
}}

**Display:**
