The BlogEdited event is fired when information about an Blog of the site is edited.  The event will be fired after the Blog information is successfully saved.

**Example:**

{{
public class MyCustomPlugin
{
    public void BlogEdited(ServiceContext context, BlogReadOnly blog)
    {
    }
}
}}
