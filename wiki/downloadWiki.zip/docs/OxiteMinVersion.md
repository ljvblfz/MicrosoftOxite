The OxiteMaxVersion attribute is applied to the plug-in class.  It allows the plug-in creator to specify the minimum version number of Oxite that the plug-in is compatible with.

**Example:**

{{
[OxiteMinVersion(1, 0, 0, 0)](OxiteMinVersion(1,-0,-0,-0))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
