The Description attribute is applied to the plug-in class.  It allows the plug-in creator to specify a description for the plug-in.

**Example:**

{{
[Description("This plug-in will allow the selecting of disclaimers to be added to blog posts.")](Description(_This-plug-in-will-allow-the-selecting-of-disclaimers-to-be-added-to-blog-posts._))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
