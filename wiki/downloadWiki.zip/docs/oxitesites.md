Sites based on some version of the Oxite code base
* [Mix Online](http://www.visitmix.com)
* [ALT.NET Community Øresund](http://oresund.altdotnet.org/)
* [Kirill Kruchkov's personal blog](http://www.dinAlt.ru)
* [KPOH Tech Blog](http://kpoh.biz/)
* [DingN](http://www.dingn.com)
* [Duncan Mackenzie's blog](http://duncanmackenzie.net)
* [Sampy's blog](http://sampy.com/)
* [Erik Porter's blog](http://erikporter.com)
* [Tobin Titus's blog](http://tobint.com)
* [The **very** yellow BananaCoding blog (about C# and Ruby)](http://www.bananacoding.com)
* [Paul's DotNet Blog](http://blog.aspnetdesigns.com)
* [Sleek Digital](http://sleekdigital.com/)
* [Nathan Heskew's blog](http://nathan.heskew.com)
* [Patient Coder](http://www.patientcoder.com)
* [MIX Videos](http://videos.visitmix.com)
* [CapitalCoder](http://capitalcoder.com/)
* [AdamKinney.com](http://adamkinney.com/)
* [Microsoft PDC](http://microsoftpdc.com)
* [Richard's Projects](http://www.richardsprojects.co.uk/)
* _your site goes here_

Let us know about your site (in the comments below) and we'll add it to this list when it is live!