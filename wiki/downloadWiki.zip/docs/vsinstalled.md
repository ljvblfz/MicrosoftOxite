**Note**: these instructions assume you already have Visual Studio/Visual Studio Express installed, and that you **do not** have the Database Professional or Test project support installed.

* If you have Visual Studio Professional or higher and the Database Professional edition installed, then [click here for instructions](vsdbpro).
* If you do not have Visual Studio installed, then [click here for instructions](gettingstarted).

## System Requirements
You can run Oxite on any version of Windows XP, Server 2003, Vista or Server 2008 (32 or 64-bit)
There are three pieces of software you need to get started:
# Some version of Visual Studio or Visual Web Developer Express (VWD Express),
# ASP.NET MVC, and
# SQL Express 2005 or 2008

If you have Visual Studio or Visual Web Developer Express already installed, then you need the beta of MVC and you need a database.

## Installing MVC
Oxite requires the Beta of ASP.NET MVC, which you can install from [the MVC Beta download page](http://www.microsoft.com/downloads/details.aspx?FamilyId=A24D1E00-CD35-4F66-BAA0-2362BDDE0766&displaylang=en)

Scroll down the page until you see the two files available for download and click on the 'Download' button next to the 1.4 MB .msi file
![](vsinstalled_http://channel9.msdn.com/Link/7ecb264d-316b-40ab-90c1-8a265fbbc982/)

Click Run and accept the warning in IE, or save it to disk and run it in Firefox. Follow the prompts all the way through the install.

It is important that we are doing this step **after** the installation of VWD Express, as the MVC Beta does some configuration of templates and features that the VWD Express product needs to be able to run MVC projects.

## Download an Oxite Release or the Oxite source
Now it is time to grab a recent release or the most current drop of the source.

### Release or Source Code checkin: Which one to get?
In general you should get the most recent release, as that is a drop of the code that we explicitly chose to package up for people to download. Individual source code checkins are more up-to-date and may contain bug fixes since a release was created, but they may also contain new bugs that just haven't been found yet. Downloading from the source code tab also brings down more files that you need, because it brings down a full copy of everything we have checked into this codeplex project. Having said that, you can look down the list of checkins to see if there is any important functionality or changes that have been done since the last release, and then make your own decision about what to download.

Regardless of what type of source you choose, you end up pulling down a .zip file full of code, images, binaries, etc... unzip that file into a folder where you have read/write access. To avoid any security access issues, I would stick with a folder that is under your user directory (a folder on the desktop or in your 'Documents' folder for example).

Open up the new directory full of files when you've extracted them. If you've downloaded a release, then the top level folders within this new folder will be the various projects that make up the Oxite sample, including /Oxite.Database, /bin, /Oxite.SearchProvider and others. This is the root of the Oxite solution. If you've downloaded a full source code check-in, then the top-level folder will contain /Archive and /Oxite, and the root of the solution will be under the /Oxite folder. Remember the path to that root folder, you'll need it in a minute.

## Open and Run Oxite!
Open up Visual Studio and click the File menu and select 'Open Project...', browse to the root of the solution wherever you extracted it to, and select the Oxite.VWDExpress.sln file.
![](vsinstalled_http://channel9.msdn.com/Link/b53e7c1d-00e9-479f-bc12-84e60bff651e/)

**Note**: if you are using a version of Visual Studio with the Database Professional tools and the Test tools available, then use the Oxite.Sample.sln solution. This solution contains the same basic code, but also has the database and test projects, both of which require additional features of Visual Studio to be installed.

Click Open to open the solution. You may be prompted that this is not a trusted location, if you aren't opening the code from your own documents folder, and you may be prompted with 'the source code provider for this solution can not be found'. In the first situation, you can click OK to ignore if it is running in a place where you have read/write permission and in the second case you can select 'Yes' to permanently remove the source code control bindings from the project. Once you have the project open, go over to the 'Solution Explorer' on the right hand side of the Visual Studio window and find the project named 'OxiteSite' in the list of projects (it should have a globe as an icon), right-click on it and choose 'Set as Startup'.
![](vsinstalled_http://channel9.msdn.com/Link/48cb9819-212a-44b1-ae76-e92bb55638cb/)

At this point, the web.config that ships with the sample is pointing at the .mdf file located in the /App_Data folder of the solution, and assumes you have SQL Server Express (2005 or 2008) installed and running as an instance called <your machine>\SQLExpress ... if that is not the case, if your instance is running at just <your machine name> (this is a choice while setting up Express, so you may have chosen differently than the default), then you need to edit the connection string in the web.config file of the main OxiteSite project.

Now you should be all set, so just click on the little green 'play' button on the toolbar of Visual Studio or press the F5 key on your keyboard... if everything works as expected, you should have a browser window open in a few moments with the sample data's first post 'World.Hello()' up and visible. 




