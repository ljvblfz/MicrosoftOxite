The Order attribute is applied to a  property of the plug-in class.  It allows the plug-in creator to specify the order that a property should be displayed in its configuration section group in the UI.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [Order(2)](Order(2))
    ...
    public string Disclaimer
    {
        get;
        set;
    }
...
}
}}

**Display:**
