The LabelText attribute is applied to a  property of the plug-in class.  It allows the plug-in creator to specify the label that should be displayed for the property in the configuration UI.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [LabelText("Disclaimer:")](LabelText(_Disclaimer__))
    ...
    public string DisclaimerText
    {
        get;
        set;
    }
...
}
}}

**Display:**
