The HomePage attribute is applied to the plug-in class.  It allows the plug-in creator to specify a Url where more information about the plug-in or it's author(s) can be found.

**Example:**

{{
[HomePage("http://lostincompilation.com")](HomePage(_http___lostincompilation.com_))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
