The Required attribute is applied to a  property of the plug-in class.  It allows the plug-in creator to specify that a property value is required to be entered at the configuration screen.  If no value is entered in the configuration screen, the appropriate error messaging is displayed.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [Required](Required)
    ...
    public string Disclaimer
    {
        get;
        set;
    }
...
}
}}

**Display:**
