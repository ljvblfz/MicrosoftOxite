The AreaAdded event is fired when a new Area is added to the site.  The event will be fired after the Area information is successfully saved.

**Example:**

{{
public class MyCustomPlugin
{
    public void AreaAdded(ServiceContext context, AreaReadOnly area)
    {
    }
}
}}