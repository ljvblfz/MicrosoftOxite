The Tags attribute is applied to the plug-in class.  It allows the plug-in creator to specify the current version of the plug-in.

**Example:**

{{
[Version(1, 0, 0, 0)](Version(1,-0,-0,-0))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
