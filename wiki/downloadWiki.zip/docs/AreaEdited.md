The AreaEdited event is fired when information about an Area of the site is edited.  The event will be fired after the Area information is successfully saved.

**Example:**

{{
public class MyCustomPlugin
{
    public void AreaEdited(ServiceContext context, AreaReadOnly area)
    {
    }
}
}}