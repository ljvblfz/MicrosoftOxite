The AuthorUrls attribute is applied to the plug-in class.  It allows the plug-in creator to specify homepage url(s) for each of the people listed in the [Authors](Authors) attribute.  There should be one entry in the AuthorUrls attribute for every Authors entry.

**Example:**

{{
[Authors("Travis Merkel", "Steve Perry")](Authors(_Travis-Merkel_,-_Steve-Perry_))
[AuthorUrls("http://lostincompilation.com", "http://www.journeymusic.com")](AuthorUrls(_http___lostincompilation.com_,-_http___www.journeymusic.com_))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
