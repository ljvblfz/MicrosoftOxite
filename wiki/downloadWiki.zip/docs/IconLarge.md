The IconLarge attribute is applied to the plug-in class.  It allows the plug-in creator to specify a large icon to displayed in association with the plug-in in the UI.  This can either be an absolute path or the simple file name of the icon if the icon file is located in the images directory of the plug-in folder structure.

![](IconLarge_folderstructure.jpg)

**Example:**

{{
[IconLarge("IconLarge.jpg")](IconLarge(_IconLarge.jpg_))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**
