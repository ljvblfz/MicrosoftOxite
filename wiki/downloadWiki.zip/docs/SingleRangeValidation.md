The SingleRangeValidation attribute is applied to a float-type property of the plug-in class.  It allows the plug-in creator to specify that the value of the property must fall within a certain range.  If the configured value is not within that range, appropriate error messaging is displayed in the UI.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [SingleRangeValidation(10, 20)](SingleRangeValidation(10,-20))
    ...
    public float DisclaimerFloat
    {
        get;
        set;
    }
...
}
}}

**Display:**
