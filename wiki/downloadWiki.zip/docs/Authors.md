The Author attribute is applied to the plug-in class.  It allows the plug-in creator to specify a list of people who created the plug-in.

**Example:**

{{
[Authors("Travis Merkel", "Steve Perry")](Authors(_Travis-Merkel_,-_Steve-Perry_))
...
public class DisclaimerSelectorPlugin
{
...
}
}}

**Display:**

![](Authors_authorsui.jpg)