The DoubleRangeValidation attribute is applied to a double-type property of the plug-in class.  It allows the plug-in creator to specify that the value of the property must fall within a certain range.  If the configured value is not within that range, appropriate error messaging is displayed in the UI.

**Example:**

{{
public class DisclaimerSelectorPlugin
{
    [DoubleRangeValidation(10, 20)](DoubleRangeValidation(10,-20))
    ...
    public double DisclaimerDouble
    {
        get;
        set;
    }
...
}
}}

**Display:**
